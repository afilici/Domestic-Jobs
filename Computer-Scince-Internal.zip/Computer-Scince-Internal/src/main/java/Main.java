import java.util.Scanner;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Main extends JFrame implements ActionListener {
    static JFrame frame1;
    static JFrame signupframe;
    static JFrame loginframe;
    static JFrame mainframe;
    static JFrame tutorframe;
    static JFrame plumersframe;
    static JFrame cleaningframe;
    static JFrame dogframe;
    static JFrame chatframe;

    static Container c1;
    static Container c2;
    static Container c3;
    static Container c4;
    static Container c5;
    static Container c6;
    static Container c7;
    static Container c8;
    static Container c9;

    static JLabel label1;
    static JLabel signuplabel;
    static JLabel label2;
    static JLabel login;
    static JLabel labelMainPage;
    static JLabel labelTutor;
    static JLabel labelPlumers;
    static JLabel labelCleaning;
    static JLabel labeldog;
    static JLabel labelchat;

    static JTextField e_username1;
    static JTextField e_username;
    static JPasswordField e_password;
    static JPasswordField e_password1;

    static JTextField e_username2;

    public static void main(String[] args) {
        new Main().home();
    }

    public void home() {
        frame1 = new JFrame("Homepage");
        frame1.setBounds(0, 0, 1400, 800);
        frame1.setLayout(null);

        c1 = frame1.getContentPane();

        label1 = new JLabel();
        label1.setIcon(new ImageIcon("homepage1.png"));
        label1.setBounds(0, 0, 1400, 800);
        c1.add(label1);

        JLabel overlay = new JLabel();
        overlay.setBounds(0, 0, 1400, 800);
        overlay.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int x = e.getX();
                int y = e.getY();

                if (x >= 527 && x <= 799 && y >= 273 && y <= 388) {
                    frame1.setVisible(false);
                    signup();
                }
            }
        });

        frame1.add(overlay);
        frame1.setVisible(true);

        JOptionPane.showMessageDialog(frame1, "Login if you are a member or signup if you are new!");
    }

    public void signup() {
        signupframe = new JFrame("Sign Up");
        signupframe.setBounds(0, 0, 1400, 800);
        signupframe.setLayout(null);

        c3 = signupframe.getContentPane();
        signuplabel = new JLabel("");
        signuplabel.setIcon(new ImageIcon("signup.png"));
        signuplabel.setBounds(0, 0, 1400, 850);

        e_username1 = new JTextField();
        e_username1.setBounds(455, 285, 370, 30);
        e_username1.setFont(new Font("Arial", Font.BOLD, 20));
        e_username1.setForeground(Color.black);
        e_username1.setBackground(Color.white);
        c3.add(e_username1);

        e_password1 = new JPasswordField();
        e_password1.setBounds(445, 425, 300, 30);
        e_password1.setFont(new Font("Arial", Font.BOLD, 20));
        e_password1.setForeground(Color.black);
        e_password1.setBackground(Color.white);
        c3.add(e_password1);

        c3.add(signuplabel);
        signupframe.setVisible(true);

        JLabel signupOverlay = new JLabel();
        signupOverlay.setBounds(0, 0, 1400, 800);
        signupOverlay.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int x = e.getX();
                int y = e.getY();
                System.out.println("Clicked at X: " + x + ", Y: " + y);

                if (x >= 547 && x <= 722 && y >= 673 && y <= 759) {
                    signupframe.setVisible(false);
                    login();
                }

                if (x >= 551 && x <= 718 && y >= 515 && y <= 581) {
                    String username = e_username1.getText().trim();

                    if (username.length() >= 3) {
                        if (usernameExists(username)) {
                            JOptionPane.showMessageDialog(signupframe, "Welcome back!");
                            signupframe.setVisible(false);
                            Main.this.mainpage();
                        } else {
                            JOptionPane.showMessageDialog(signupframe, "Account does not exist. Please log in to create one.");
                        }
                    } else {
                        JOptionPane.showMessageDialog(signupframe, "Username must be at least 3 characters.");
                    }
                }
            }
        });

        c3.add(signupOverlay);
    }

    public boolean usernameExists(String username) {
        try (BufferedReader reader = new BufferedReader(new FileReader("users.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 1 && parts[0].equals(username)) {
                    return true;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    public void login() {
        loginframe = new JFrame("Employee Login");
        loginframe.setBounds(0, 0, 1700, 900);
        loginframe.setLayout(null);

        c2 = loginframe.getContentPane();

        e_username = new JTextField();
        e_username.setBounds(360, 305, 300, 30);
        e_username.setFont(new Font("Arial", Font.BOLD, 20));
        c2.add(e_username);

        e_password = new JPasswordField();
        e_password.setBounds(400, 525, 300, 30);
        e_password.setFont(new Font("Arial", Font.BOLD, 20));
        c2.add(e_password);

        login = new JLabel();
        login.setIcon(new ImageIcon("login.png"));
        login.setBounds(0, 0, 1700, 900);
        c2.add(login);

        JLabel overlay = new JLabel();
        overlay.setBounds(0, 0, 1700, 900);
        overlay.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int x = e.getX();
                int y = e.getY();
                System.out.println("Clicked at X: " + x + ", Y: " + y);

                if (x >= 1134 && x <= 1316 && y >= 105 && y <= 169) {
                    loginframe.setVisible(false);
                    mainpage();
                }

                if (x >= 560 && x <= 722 && y >= 667 && y <= 731) {
                    String username = e_username.getText().trim();
                    String password = new String(e_password.getPassword()).trim();

                    if (username.length() >= 3 && password.length() >= 3) {
                        if (!usernameExists(username)) {
                            try (FileWriter fw = new FileWriter("users.txt", true)) {
                                fw.write(username + "," + password + "\n");
                                JOptionPane.showMessageDialog(loginframe, "Account created and logged in!");
                                loginframe.setVisible(false);
                                mainpage();
                            } catch (IOException ex) {
                                JOptionPane.showMessageDialog(loginframe, "Error writing to file.");
                            }
                        } else {
                            JOptionPane.showMessageDialog(loginframe, "Username already exists. Please sign up instead.");
                        }
                    } else {
                        JOptionPane.showMessageDialog(loginframe, "Username and password must be at least 3 characters.");
                    }
                }
            }
        });

        c2.add(overlay);
        loginframe.setVisible(true);
    }

    public void mainpage() {
        mainframe = new JFrame("Mainpage");
        mainframe.setBounds(0, 0, 1700, 900);
        mainframe.setLayout(null);

        c4 = mainframe.getContentPane();
        c4.setLayout(null); // Ensure manual positioning works

        // Search bar placed higher on the screen
        JTextField jobSearchField = new JTextField();
        jobSearchField.setBounds(551, 200, 300, 50); // higher up
        jobSearchField.setFont(new Font("Arial", Font.PLAIN, 18));
        c4.add(jobSearchField);

        JButton searchButton = new JButton("Search");
        searchButton.setBounds(865, 200, 100, 50); // aligned with the field
        c4.add(searchButton);

        searchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String input = jobSearchField.getText().trim();
                if (input.length() >= 2) {
                    if (jobExists(input)) {
                        JOptionPane.showMessageDialog(mainframe, "Job found: " + input);
                        mainframe.setVisible(false);
                        chat(); // redirect to chat
                    } else {
                        JOptionPane.showMessageDialog(mainframe, "Job not found.");
                    }
                } else {
                    JOptionPane.showMessageDialog(mainframe, "Please enter at least 2 characters.");
                }
            }
        });

        // Overlay to handle image-based click areas
        JLabel overlay = new JLabel();
        overlay.setBounds(0, 0, 1700, 900);
        overlay.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int x = e.getX();
                int y = e.getY();
                System.out.println("Clicked at X: " + x + ", Y: " + y);

                if (x >= 54 && x <= 340 && y >= 520 && y <= 723) {
                    mainframe.setVisible(false);
                    tutors(); // redirect to tutors homepage
                }
                if (x >= 363 && x <= 662 && y >= 510 && y <= 734) {
                    mainframe.setVisible(false);
                    plumers(); // redirect to plumbers page
                }
                if (x >= 675 && x <= 975 && y >= 516 && y <= 739) {
                    mainframe.setVisible(false);
                    cleaning(); // redirect to cleaning services
                }
                if (x >= 992 && x <= 1289 && y >= 519 && y <= 736) {
                    mainframe.setVisible(false);
                    dogwalkers(); // redirect to dog walkers
                }
            }
        });
        c4.add(overlay);

        // Background image (added last so it appears behind everything)
        labelMainPage = new JLabel();
        labelMainPage.setIcon(new ImageIcon("mainpage.png"));
        labelMainPage.setBounds(0, 0, 1700, 900);
        c4.add(labelMainPage);

        mainframe.setVisible(true);
    }

    // Updated method to check if a job exists in jobs.txt
    public boolean jobExists(String jobTitle) {
        try (BufferedReader reader = new BufferedReader(new FileReader("jobs.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] jobNames = line.split(",");
                for (String job : jobNames) {
                    if (job.trim().equalsIgnoreCase(jobTitle.trim())) {
                        return true;
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }


    public void tutors(){
        tutorframe = new JFrame("Tutors");
        tutorframe.setBounds(0, 0, 1700, 900);
        tutorframe.setLayout(null);

        c5 = tutorframe.getContentPane();
        
        labelTutor = new JLabel();
        labelTutor.setIcon(new ImageIcon("tutors.png"));
        labelTutor.setBounds(0, 0, 1700, 900);
        c5.add(labelTutor);

        JLabel overlay = new JLabel();
        overlay.setBounds(0, 0, 1700, 900);
        overlay.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int x = e.getX();
                int y = e.getY();
                //System.out.println("Clicked at X: " + x + ", Y: " + y);
                if (x >= 13  && x <= 1314 && y >= 310 && y <= 777){
                    tutorframe.setVisible(false);
                    chat(); // c¿redirect to chat 
                    
                }
        
            }
        });
        c5.add(overlay);
        tutorframe.setVisible(true);

    }


    public void plumers(){
        plumersframe = new JFrame("Plumers");
        plumersframe.setBounds(0, 0, 1700, 900);
        plumersframe.setLayout(null);

        c6 =plumersframe.getContentPane();

        labelPlumers = new JLabel();
        labelPlumers.setIcon(new ImageIcon("plumers.png"));
        labelPlumers.setBounds(0, 0, 1700, 900);
        c6.add(labelPlumers);

        JLabel overlay = new JLabel();
        overlay.setBounds(0, 0, 1700, 900);
        overlay.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int x = e.getX();
                int y = e.getY();
                //System.out.println("Clicked at X: " + x + ", Y: " + y);
                if (x >= 4  && x <= 1469 && y >= 124 && y <= 834){
                    plumersframe.setVisible(false);
                    chat(); // redirect to chat
                    
                }

            }
        });
        c6.add(overlay);
        plumersframe.setVisible(true);

    }


    public void cleaning(){
        cleaningframe = new JFrame("cleaning");
        cleaningframe.setBounds(0, 0, 1700, 900);
        cleaningframe.setLayout(null);

        c7 =cleaningframe.getContentPane();

        labelCleaning= new JLabel();
        labelCleaning.setIcon(new ImageIcon("clean.png"));
        labelCleaning.setBounds(0, 0, 1700, 900);
        c7.add(labelCleaning);

        JLabel overlay = new JLabel();
        overlay.setBounds(0, 0, 1700, 900);
        overlay.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int x = e.getX();
                int y = e.getY();
                System.out.println("Clicked at X: " + x + ", Y: " + y);
                if (x >=  2 && x <= 1441 && y >= 221 && y <= 833){
                    cleaningframe.setVisible(false);
                    chat();
                    
                }

            }
        });
        c7.add(overlay);
        cleaningframe.setVisible(true);

    }


    public void dogwalkers(){
        dogframe = new JFrame("Dog walkers");
        dogframe.setBounds(0, 0, 1700, 900);
        dogframe.setLayout(null);

        c8 = dogframe.getContentPane();

        labeldog= new JLabel();
        labeldog.setIcon(new ImageIcon("dog.png"));
        labeldog.setBounds(0, 0, 1700, 900);
        c8.add(labeldog);

        JLabel overlay = new JLabel();
        overlay.setBounds(0, 0, 1700, 900);
        overlay.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int x = e.getX();
                int y = e.getY();
                System.out.println("Clicked at X: " + x + ", Y: " + y);
                if (x >=  6 && x <= 1480 && y >= 129 && y <= 837){
                    dogframe.setVisible(false);
                    chat();
                    
                }

            }
        });
        c8.add(overlay);
        dogframe.setVisible(true);

    }

    public void chat(){
        chatframe = new JFrame("Chat");
        chatframe .setBounds(0, 0, 1700, 900);
        chatframe .setLayout(null);

        c9 = chatframe.getContentPane();

        labelchat = new JLabel();
        labelchat.setIcon(new ImageIcon("chat.png"));
        labelchat.setBounds(0, 0, 1700, 900);
        c9.add( labelchat);

        JLabel overlay = new JLabel();
        overlay.setBounds(0, 0, 1700, 900);
        overlay.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int x = e.getX();
                int y = e.getY();
                System.out.println("Clicked at X: " + x + ", Y: " + y);
               

            }
        });
        c9.add(overlay);
        chatframe.setVisible(true);

    }


    

    

    

    


    Main() {
        label1 = new JLabel("");
        label1.setBounds(0, 0, 1400, 800);

        label1.addMouseListener(new MouseListener() {
            public void mouseClicked(MouseEvent e) {
                int x = e.getX();
                int y = e.getY();
                System.out.println("Clicked at X: " + x + ", Y: " + y);
            }

            public void mousePressed(MouseEvent e) {}
            public void mouseReleased(MouseEvent e) {}
            public void mouseEntered(MouseEvent e) {}
            public void mouseExited(MouseEvent e) {}
        });
    }

    public void actionPerformed(ActionEvent e) {
        // Placeholder for events
    }
}
